// Simple cache-first service worker (runtime caching for everything)
const CACHE = 'polylookup-web-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)));
    await clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(req);
    if (cached) return cached;
    try {
      const res = await fetch(req);
      if (res && res.status === 200 && req.method === 'GET') {
        cache.put(req, res.clone());
      }
      return res;
    } catch (e) {
      return cached || new Response('Offline and not cached', { status: 503 });
    }
  })());
});
