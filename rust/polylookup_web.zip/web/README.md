# polylookup web bundle (drop-in)

This folder is ready to be dropped into a Capacitor/Tauri project as your `webDir` (or served directly as a static site).

## Steps

1) Build the WASM package from your Rust crate:
   ```bash
   wasm-pack build --release --target web
   ```

2) Copy the generated `pkg/` folder **into this `web/` folder** (so you have `web/pkg/...`).

3) Put your FlatGeobuf at: `web/data/layer.fgb` (create `data/` if needed). Make sure it's **EPSG:4326 (lon/lat)** or adjust your engine to transform.

4) Serve or run in Capacitor:
   - Static server (for quick test): `python3 -m http.server -d web 8080`
   - Capacitor: set `webDir: "web"` in `capacitor.config.ts`, then `npx cap copy` and run iOS/Android.
   - Service worker is optional; assets are bundled in the app anyway.

### Querying
- Open `index.html`. Click **Load layer**, then **Query point**. Default point is Berlin (13.4178058, 52.5167835).
- The page calls `WasmLayer.loadLayerFromBytes(bytes)` and `queryPointJSON(lon, lat)` exported by your crate's WASM facade (`src/wasm.rs`).

### Notes
- If your primary attribute is named `KWB` and is numeric, the WASM facade example reads it as `i64` and includes it in the JSON results. Adjust as needed.
- For big files you may want to enable HTTP compression on the server; in Capacitor the file is read locally so it's instant.
